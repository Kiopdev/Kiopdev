import { useEffect, useRef, useState } from 'react';
import { 
  Terminal, 
  Code2, 
  Palette, 
  Crown, 
  TreePine, 
  PenTool, 
  Brain,
  Mountain,
  Mail,
  Github,
  Twitter,
  Linkedin,
  ChevronRight,
  Quote,
  Sparkles,
  Leaf,
  MapPin,
  BookOpen,
  Gamepad2,
  Tv,
  Heart
} from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import './App.css';

gsap.registerPlugin(ScrollTrigger);

// Matrix Rain Background
function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
    const fontSize = 14;
    const columns = canvas.width / fontSize;
    const drops: number[] = Array(Math.floor(columns)).fill(1);
    
    let animationId: number;
    
    const draw = () => {
      ctx.fillStyle = 'rgba(10, 10, 15, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      ctx.fillStyle = '#22c55e';
      ctx.font = `${fontSize}px monospace`;
      
      for (let i = 0; i < drops.length; i++) {
        const char = chars[Math.floor(Math.random() * chars.length)];
        ctx.fillText(char, i * fontSize, drops[i] * fontSize);
        
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
      
      animationId = requestAnimationFrame(draw);
    };
    
    draw();
    
    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-0 opacity-30"
    />
  );
}

// Typing Effect Component
function TypeWriter({ text, delay = 0, speed = 50 }: { text: string; delay?: number; speed?: number }) {
  const [displayText, setDisplayText] = useState('');
  const [started, setStarted] = useState(false);
  
  useEffect(() => {
    const timeout = setTimeout(() => setStarted(true), delay);
    return () => clearTimeout(timeout);
  }, [delay]);
  
  useEffect(() => {
    if (!started) return;
    
    let index = 0;
    const interval = setInterval(() => {
      if (index <= text.length) {
        setDisplayText(text.slice(0, index));
        index++;
      } else {
        clearInterval(interval);
      }
    }, speed);
    
    return () => clearInterval(interval);
  }, [started, text, speed]);
  
  return (
    <span className="cursor-blink">{displayText}</span>
  );
}

// Navigation
function Navigation() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  
  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 100);
    };
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const navItems = [
    { id: 'home', label: '~/home' },
    { id: 'about', label: '~/about' },
    { id: 'interests', label: '~/interests' },
    { id: 'philosophy', label: '~/philosophy' },
    { id: 'lifestyle', label: '~/lifestyle' },
    { id: 'writing', label: '~/writing' },
    { id: 'contact', label: '~/contact' }
  ];
  
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
    }
  };
  
  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-transform duration-500 ${
      isVisible ? 'translate-y-0' : '-translate-y-full'
    }`}>
      <div className="backdrop-blur-xl bg-[#0a0a0f]/90 border-b border-[#1a1a24]">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <a 
              href="#home" 
              onClick={(e) => { e.preventDefault(); scrollToSection('home'); }}
              className="text-xl font-bold font-mono"
            >
              <span className="text-[#22c55e]">kiop</span>
              <span className="text-white">@</span>
              <span className="text-[#a855f7]">dev</span>
              <span className="text-white">:~$</span>
            </a>
            
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  onClick={(e) => { e.preventDefault(); scrollToSection(item.id); }}
                  className={`px-4 py-2 text-sm font-mono rounded-lg transition-all ${
                    activeSection === item.id 
                      ? 'text-[#22c55e] bg-[#22c55e]/10' 
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

// Hero Section
function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.hero-terminal',
        { opacity: 0, y: 50 },
        { opacity: 1, y: 0, duration: 1, ease: 'power3.out', delay: 0.3 }
      );
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <section 
      id="home" 
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center px-6"
    >
      <div className="hero-terminal w-full max-w-4xl">
        <div className="terminal-window">
          <div className="terminal-header">
            <div className="terminal-dot red" />
            <div className="terminal-dot yellow" />
            <div className="terminal-dot green" />
            <span className="ml-4 text-sm text-gray-500 font-mono">kiop@portfolio — zsh</span>
          </div>
          
          <div className="terminal-body space-y-4">
            <div className="terminal-line">
              <span className="terminal-prompt">kiop@dev:~$</span>
              <span className="terminal-content">
                <TypeWriter text="whoami" delay={500} speed={80} />
              </span>
            </div>
            
            <div className="terminal-line">
              <span className="terminal-prompt" />
              <span className="terminal-content">
                <span className="code-keyword">const</span>{' '}
                <span className="code-variable">developer</span>{' '}
                <span className="code-operator">=</span>{' '}
                <span className="code-string">&quot;Kiopdev&quot;</span>;
              </span>
            </div>
            
            <div className="terminal-line">
              <span className="terminal-prompt" />
              <span className="terminal-content text-gray-400">
                <span className="code-comment">// Also known as Kiop — my digital identity</span>
              </span>
            </div>
            
            <div className="terminal-line">
              <span className="terminal-prompt">kiop@dev:~$</span>
              <span className="terminal-content">
                <TypeWriter text="cat about.txt" delay={1500} speed={80} />
              </span>
            </div>
            
            <div className="terminal-line">
              <span className="terminal-prompt" />
              <span className="terminal-content">
                <p className="text-lg leading-relaxed">
                  A <span className="code-function">developer</span> who enjoys building things that{' '}
                  <span className="text-[#22c55e]">make sense</span>, feel{' '}
                  <span className="text-[#a855f7]">meaningful</span>, and work{' '}
                  <span className="text-[#3b82f6]">logically</span> under the hood.
                </p>
              </span>
            </div>
            
            <div className="terminal-line">
              <span className="terminal-prompt">kiop@dev:~$</span>
              <span className="terminal-content">
                <TypeWriter text="ls -la interests/" delay={2500} speed={60} />
              </span>
            </div>
            
            <div className="terminal-line">
              <span className="terminal-prompt" />
              <span className="terminal-content font-mono text-sm">
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <span className="text-[#eab308]">drwxr-xr-x</span>{' '}
                  <span>drawing/</span>
                  <span className="text-[#eab308]">drwxr-xr-x</span>{' '}
                  <span>chess/</span>
                  <span className="text-[#eab308]">drwxr-xr-x</span>{' '}
                  <span>anime/</span>
                  <span className="text-[#eab308]">drwxr-xr-x</span>{' '}
                  <span>philosophy/</span>
                  <span className="text-[#eab308]">drwxr-xr-x</span>{' '}
                  <span>nature/</span>
                  <span className="text-[#eab308]">drwxr-xr-x</span>{' '}
                  <span>writing/</span>
                </div>
              </span>
            </div>
            
            <div className="terminal-line">
              <span className="terminal-prompt">kiop@dev:~$</span>
              <span className="terminal-content cursor-blink">_</span>
            </div>
          </div>
        </div>
        
        <div className="flex justify-center mt-12">
          <div className="flex flex-col items-center gap-2 text-gray-500 animate-bounce">
            <span className="text-sm font-mono">scroll to explore</span>
            <ChevronRight className="w-5 h-5 rotate-90" />
          </div>
        </div>
      </div>
    </section>
  );
}

// About Section
function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.about-card',
        { opacity: 0, x: -50 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          stagger: 0.2,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <section 
      id="about" 
      ref={sectionRef}
      className="relative py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <Terminal className="w-6 h-6 text-[#22c55e]" />
            <span className="text-[#22c55e] font-mono text-sm">~/about</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white font-mono">
            <span className="code-keyword">class</span>{' '}
            <span className="code-function">AboutMe</span>{' '}
            <span className="text-white">{'{'}</span>
          </h2>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="about-card code-block card-hover">
            <div className="code-header">
              <span className="code-lang">identity.js</span>
              <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-[#ef4444]" />
                <div className="w-3 h-3 rounded-full bg-[#eab308]" />
                <div className="w-3 h-3 rounded-full bg-[#22c55e]" />
              </div>
            </div>
            <div className="code-content line-numbers">
              <div className="line"><span className="code-keyword">const</span> <span className="code-variable">identity</span> = {'{'}</div>
              <div className="line">  name: <span className="code-string">&quot;Kiop&quot;</span>,</div>
              <div className="line">  alias: <span className="code-string">&quot;Kiopdev&quot;</span>,</div>
              <div className="line">  role: <span className="code-string">&quot;Developer&quot;</span>,</div>
              <div className="line">  type: <span className="code-string">&quot;Digital Identity&quot;</span></div>
              <div className="line">{'}'};</div>
            </div>
          </div>
          
          <div className="about-card code-block card-hover">
            <div className="code-header">
              <span className="code-lang">mindset.js</span>
              <Brain className="w-4 h-4 text-[#a855f7]" />
            </div>
            <div className="code-content line-numbers">
              <div className="line"><span className="code-keyword">const</span> <span className="code-variable">thinking</span> = {'{'}</div>
              <div className="line">  style: <span className="code-string">&quot;Logical & Critical&quot;</span>,</div>
              <div className="line">  approach: <span className="code-string">&quot;Analytical&quot;</span>,</div>
              <div className="line">  trait: <span className="code-string">&quot;Strategic Overthinker&quot;</span>,</div>
              <div className="line">  method: <span className="code-string">&quot;Break ideas apart&quot;</span></div>
              <div className="line">{'}'};</div>
            </div>
          </div>
          
          <div className="about-card code-block card-hover">
            <div className="code-header">
              <span className="code-lang">values.js</span>
              <Heart className="w-4 h-4 text-[#ef4444]" />
            </div>
            <div className="code-content line-numbers">
              <div className="line"><span className="code-keyword">const</span> <span className="code-variable">values</span> = {'{'}</div>
              <div className="line">  dharma: <span className="code-number">true</span>,</div>
              <div className="line">  selfAwareness: <span className="code-number">true</span>,</div>
              <div className="line">  discipline: <span className="code-number">true</span>,</div>
              <div className="line">  growth: <span className="code-string">&quot;continuous&quot;</span></div>
              <div className="line">{'}'};</div>
            </div>
          </div>
          
          <div className="about-card code-block card-hover">
            <div className="code-header">
              <span className="code-lang">philosophy.js</span>
              <Sparkles className="w-4 h-4 text-[#eab308]" />
            </div>
            <div className="code-content line-numbers">
              <div className="line"><span className="code-comment">// Life approach</span></div>
              <div className="line"><span className="code-keyword">function</span> <span className="code-function">live</span>() {'{'}</div>
              <div className="line">  <span className="code-keyword">return</span> {'{'}</div>
              <div className="line">    learn: <span className="code-string">&quot;always&quot;</span>,</div>
              <div className="line">    question: <span className="code-string">&quot;everything&quot;</span>,</div>
              <div className="line">    grow: <span className="code-string">&quot;constantly&quot;</span></div>
              <div className="line">  {'}'};</div>
              <div className="line">{'}'}</div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 text-4xl font-bold text-white font-mono">
          {'}'}
        </div>
      </div>
    </section>
  );
}

// Interests Section
function InterestsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [activeTab, setActiveTab] = useState('drawing');
  
  const interests = {
    drawing: {
      icon: Palette,
      title: 'Drawing',
      color: '#a855f7',
      description: 'Visual expression of ideas. Drawing helps me translate abstract concepts into tangible forms, bridging the gap between imagination and reality.',
      code: `function createArt() {
  const idea = imagination.capture();
  const sketch = pencil.sketch(idea);
  return art.refine(sketch);
}`
    },
    chess: {
      icon: Crown,
      title: 'Chess',
      color: '#eab308',
      description: 'Strategy, patience, and mental discipline. Chess teaches me to think several moves ahead and consider consequences before acting.',
      code: `function playChess() {
  while (game.inProgress) {
    analyze(position);
    calculate(variants);
    execute(bestMove);
    patience++;
  }
}`
    },
    anime: {
      icon: Tv,
      title: 'Anime',
      color: '#ec4899',
      description: 'Storytelling, philosophy, and character depth. Anime offers profound narratives that explore human nature and existential questions.',
      code: `function watchAnime() {
  const story = new Narrative();
  story.add(philosophy);
  story.add(characterDepth);
  return inspiration.extract(story);
}`
    }
  };
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.interest-tab',
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          stagger: 0.1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  const ActiveIcon = interests[activeTab as keyof typeof interests].icon;
  const activeData = interests[activeTab as keyof typeof interests];
  
  return (
    <section 
      id="interests" 
      ref={sectionRef}
      className="relative py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <Gamepad2 className="w-6 h-6 text-[#22c55e]" />
            <span className="text-[#22c55e] font-mono text-sm">~/interests</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white font-mono">
            <span className="code-keyword">import</span>{' '}
            <span className="text-white">{'{'}</span>{' '}
            <span className="code-variable">Interests</span>{' '}
            <span className="text-white">{'}'}</span>{' '}
            <span className="code-keyword">from</span>{' '}
            <span className="code-string">&quot;./life&quot;</span>;
          </h2>
        </div>
        
        <div className="flex flex-wrap gap-4 mb-8">
          {Object.entries(interests).map(([key, data]) => {
            const Icon = data.icon;
            return (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`interest-tab flex items-center gap-3 px-6 py-3 rounded-xl border transition-all ${
                  activeTab === key 
                    ? 'border-[#22c55e] bg-[#22c55e]/10 text-white' 
                    : 'border-[#1a1a24] bg-[#0d0d12] text-gray-400 hover:border-gray-600'
                }`}
              >
                <Icon className="w-5 h-5" style={{ color: data.color }} />
                <span className="font-mono">{data.title}</span>
              </button>
            );
          })}
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8">
          <div className="code-block">
            <div className="code-header">
              <span className="code-lang">{activeTab}.md</span>
              <ActiveIcon className="w-4 h-4" style={{ color: activeData.color }} />
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-bold mb-4" style={{ color: activeData.color }}>
                {activeData.title}
              </h3>
              <p className="text-gray-300 leading-relaxed text-lg">
                {activeData.description}
              </p>
            </div>
          </div>
          
          <div className="code-block">
            <div className="code-header">
              <span className="code-lang">{activeTab}.js</span>
              <Code2 className="w-4 h-4 text-[#22c55e]" />
            </div>
            <div className="code-content line-numbers">
              {activeData.code.split('\n').map((line, i) => (
                <div key={i} className="line whitespace-pre">{line}</div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Philosophy Section
function PhilosophySection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.philosophy-card',
        { opacity: 0, scale: 0.95 },
        {
          opacity: 1,
          scale: 1,
          stagger: 0.15,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <section 
      id="philosophy" 
      ref={sectionRef}
      className="relative py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <Sparkles className="w-6 h-6 text-[#a855f7]" />
            <span className="text-[#a855f7] font-mono text-sm">~/philosophy</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white font-mono">
            <span className="code-comment">// Spiritual & Philosophical Core</span>
          </h2>
        </div>
        
        <div className="philosophy-card code-block mb-8 glow-purple">
          <div className="code-header">
            <span className="code-lang">spirituality.js</span>
            <span className="text-[#eab308]">ॐ</span>
          </div>
          <div className="p-8">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#eab308]/20 to-[#a855f7]/20 flex items-center justify-center flex-shrink-0">
                <span className="text-4xl">🕉️</span>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white mb-3 font-mono">
                  Inspired by <span className="text-[#eab308]">Lord Krishna</span>
                </h3>
                <p className="text-gray-300 leading-relaxed mb-4">
                  Not just as a deity, but as a symbol of <span className="text-[#22c55e]">wisdom</span>,{' '}
                  <span className="text-[#3b82f6]">balance</span>, and{' '}
                  <span className="text-[#a855f7]">detached action</span>.
                </p>
                <div className="code-content line-numbers mt-4">
                  <div className="line"><span className="code-keyword">const</span> <span className="code-variable">path</span> = {'{'}</div>
                  <div className="line">  follow: <span className="code-string">&quot;dharma&quot;</span>,</div>
                  <div className="line">  practice: <span className="code-string">&quot;self-awareness&quot;</span>,</div>
                  <div className="line">  value: <span className="code-string">&quot;inner discipline&quot;</span>,</div>
                  <div className="line">  reject: <span className="code-string">&quot;blind rituals&quot;</span></div>
                  <div className="line">{'}'};</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="philosophy-card relative p-8 rounded-2xl border border-[#1a1a24] bg-gradient-to-r from-[#22c55e]/5 to-[#a855f7]/5">
          <Quote className="absolute top-6 left-6 w-10 h-10 text-[#22c55e]/30" />
          <blockquote className="text-xl md:text-2xl text-center text-gray-200 font-mono italic pt-8">
            &quot;Karmanye vadhikaraste ma phaleshu kadachana&quot;
          </blockquote>
          <p className="text-center text-gray-500 mt-4 font-mono text-sm">
            You have the right to work only, but never to its fruits.
          </p>
        </div>
      </div>
    </section>
  );
}

// Lifestyle Section
function LifestyleSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.lifestyle-item',
        { opacity: 0, x: -30 },
        {
          opacity: 1,
          x: 0,
          stagger: 0.1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  const lifestyleItems = [
    {
      icon: TreePine,
      title: 'Nature Lover',
      description: 'Drawn to simplicity and clarity found in natural environments.',
      color: '#22c55e'
    },
    {
      icon: Leaf,
      title: 'Vegetarian',
      description: 'A conscious choice aligned with compassion and sustainability.',
      color: '#16a34a'
    },
    {
      icon: MapPin,
      title: 'Dream Destinations',
      description: 'Canada & Switzerland — inspired by their balance of nature, order, and quality of life.',
      color: '#3b82f6'
    },
    {
      icon: Mountain,
      title: 'Simplicity Seeker',
      description: 'Finding beauty in minimalism and clarity over complexity.',
      color: '#a855f7'
    }
  ];
  
  return (
    <section 
      id="lifestyle" 
      ref={sectionRef}
      className="relative py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <Leaf className="w-6 h-6 text-[#22c55e]" />
            <span className="text-[#22c55e] font-mono text-sm">~/lifestyle</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white font-mono">
            <span className="code-keyword">export const</span>{' '}
            <span className="code-variable">lifestyle</span>{' '}
            <span className="code-operator">=</span>{' '}
            <span className="text-white">[</span>
          </h2>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {lifestyleItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div 
                key={index}
                className="lifestyle-item code-block card-hover"
              >
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${item.color}20` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: item.color }} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white mb-2 font-mono">
                        {item.title}
                      </h3>
                      <p className="text-gray-400 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-8 text-4xl font-bold text-white font-mono">
          ];
        </div>
      </div>
    </section>
  );
}

// Writing Section
function WritingSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.writing-content',
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <section 
      id="writing" 
      ref={sectionRef}
      className="relative py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <PenTool className="w-6 h-6 text-[#ec4899]" />
            <span className="text-[#ec4899] font-mono text-sm">~/writing</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white font-mono">
            <span className="code-function">write</span>
            <span className="text-white">(</span>
            <span className="code-variable">ideas</span>
            <span className="text-white">,</span>{' '}
            <span className="code-variable">thoughts</span>
            <span className="text-white">,</span>{' '}
            <span className="code-variable">reflections</span>
            <span className="text-white">);</span>
          </h2>
        </div>
        
        <div className="writing-content grid lg:grid-cols-2 gap-8">
          <div className="code-block">
            <div className="code-header">
              <span className="code-lang">why_i_write.md</span>
              <BookOpen className="w-4 h-4 text-[#ec4899]" />
            </div>
            <div className="p-8">
              <p className="text-gray-300 leading-relaxed text-lg mb-6">
                Writing is more than just putting words on paper. It&apos;s a way to{' '}
                <span className="text-[#22c55e]">organize my mind</span> and explore perspectives beyond surface-level thinking.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <ChevronRight className="w-5 h-5 text-[#22c55e]" />
                  <span className="text-gray-400">Ideas and concepts</span>
                </div>
                <div className="flex items-center gap-3">
                  <ChevronRight className="w-5 h-5 text-[#22c55e]" />
                  <span className="text-gray-400">Personal thoughts</span>
                </div>
                <div className="flex items-center gap-3">
                  <ChevronRight className="w-5 h-5 text-[#22c55e]" />
                  <span className="text-gray-400">Deep reflections</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="code-block">
            <div className="code-header">
              <span className="code-lang">writing_process.js</span>
              <Code2 className="w-4 h-4 text-[#22c55e]" />
            </div>
            <div className="code-content line-numbers">
              <div className="line"><span className="code-keyword">function</span> <span className="code-function">write</span>(<span className="code-variable">topic</span>) {'{'}</div>
              <div className="line">  <span className="code-keyword">const</span> <span className="code-variable">thoughts</span> = mind.<span className="code-function">organize</span>(topic);</div>
              <div className="line">  <span className="code-keyword">const</span> <span className="code-variable">perspectives</span> = thoughts.<span className="code-function">explore</span>();</div>
              <div className="line">  <span className="code-keyword">const</span> <span className="code-variable">draft</span> = pen.<span className="code-function">write</span>(perspectives);</div>
              <div className="line">  <span className="code-keyword">return</span> draft.<span className="code-function">refine</span>();</div>
              <div className="line">{'}'}</div>
              <div className="line" />
              <div className="line"><span className="code-comment">// Writing helps me think clearer</span></div>
              <div className="line"><span className="code-function">write</span>(<span className="code-string">&quot;life&quot;</span>);</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Skills Section
function SkillsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [animated, setAnimated] = useState(false);
  
  const skills = [
    { name: 'Logical Thinking', level: 95, color: '#22c55e' },
    { name: 'Problem Solving', level: 90, color: '#3b82f6' },
    { name: 'Critical Analysis', level: 88, color: '#a855f7' },
    { name: 'Strategic Planning', level: 85, color: '#eab308' },
    { name: 'Creative Expression', level: 82, color: '#ec4899' },
    { name: 'Self Discipline', level: 90, color: '#06b6d4' }
  ];
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top 70%',
        onEnter: () => setAnimated(true)
      });
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  return (
    <section 
      ref={sectionRef}
      className="relative py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <Code2 className="w-6 h-6 text-[#22c55e]" />
            <span className="text-[#22c55e] font-mono text-sm">~/skills</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white font-mono">
            <span className="code-variable">skills</span>
            <span className="code-operator">.</span>
            <span className="code-function">map</span>
            <span className="text-white">(</span>
            <span className="code-variable">skill</span>{' '}
            <span className="code-operator">=&gt;</span>{' '}
            <span className="code-variable">skill</span>
            <span className="text-white">);</span>
          </h2>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {skills.map((skill, index) => (
            <div key={index} className="code-block p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-white font-mono">{skill.name}</span>
                <span className="text-sm" style={{ color: skill.color }}>{skill.level}%</span>
              </div>
              <div className="h-2 bg-[#1a1a24] rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-1000 ease-out"
                  style={{ 
                    width: animated ? `${skill.level}%` : '0%',
                    backgroundColor: skill.color,
                    transitionDelay: `${index * 100}ms`
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Contact Section
function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.contact-content',
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);
    
    return () => ctx.revert();
  }, []);
  
  const socialLinks = [
    { icon: Github, label: 'GitHub', href: '#', color: '#6b7280' },
    { icon: Twitter, label: 'Twitter', href: '#', color: '#3b82f6' },
    { icon: Linkedin, label: 'LinkedIn', href: '#', color: '#3b82f6' },
    { icon: Mail, label: 'Email', href: 'mailto:kiop@dev.com', color: '#ef4444' }
  ];
  
  return (
    <section 
      id="contact" 
      ref={sectionRef}
      className="relative py-32 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <div className="flex items-center gap-4 mb-4">
            <Mail className="w-6 h-6 text-[#22c55e]" />
            <span className="text-[#22c55e] font-mono text-sm">~/contact</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white font-mono">
            <span className="code-function">connect</span>
            <span className="text-white">();</span>
          </h2>
        </div>
        
        <div className="contact-content grid lg:grid-cols-2 gap-12">
          <div>
            <div className="terminal-window mb-8">
              <div className="terminal-header">
                <div className="terminal-dot red" />
                <div className="terminal-dot yellow" />
                <div className="terminal-dot green" />
                <span className="ml-4 text-sm text-gray-500 font-mono">message.txt</span>
              </div>
              <div className="terminal-body">
                <p className="text-gray-300 leading-relaxed text-lg">
                  Always learning, always questioning, always trying to grow.
                </p>
                <p className="text-gray-400 mt-4">
                  If you want to discuss code, philosophy, chess, or just say hi — feel free to reach out.
                </p>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4">
              {socialLinks.map(({ icon: Icon, label, href, color }) => (
                <a
                  key={label}
                  href={href}
                  className="flex items-center gap-3 px-6 py-3 bg-[#0d0d12] border border-[#1a1a24] rounded-xl hover:border-[#22c55e] transition-all group"
                >
                  <Icon className="w-5 h-5" style={{ color }} />
                  <span className="text-gray-300 group-hover:text-white font-mono">{label}</span>
                </a>
              ))}
            </div>
          </div>
          
          <div className="code-block">
            <div className="code-header">
              <span className="code-lang">contact.js</span>
              <Code2 className="w-4 h-4 text-[#22c55e]" />
            </div>
            <div className="code-content line-numbers">
              <div className="line"><span className="code-keyword">const</span> <span className="code-variable">kiop</span> = {'{'}</div>
              <div className="line">  identity: <span className="code-string">&quot;Kiopdev&quot;</span>,</div>
              <div className="line">  alias: <span className="code-string">&quot;Kiop&quot;</span>,</div>
              <div className="line">  role: <span className="code-string">&quot;Developer & Thinker&quot;</span>,</div>
              <div className="line">  status: <span className="code-string">&quot;Always learning&quot;</span>,</div>
              <div className="line">  available: <span className="code-number">true</span></div>
              <div className="line">{'}'};</div>
              <div className="line" />
              <div className="line"><span className="code-comment">// Let&apos;s connect</span></div>
              <div className="line"><span className="code-function">connect</span>(kiop);</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  return (
    <footer className="relative py-16 px-6 border-t border-[#1a1a24]">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-2xl font-bold font-mono">
            <span className="text-[#22c55e]">kiop</span>
            <span className="text-white">@</span>
            <span className="text-[#a855f7]">dev</span>
          </div>
          
          <p className="text-gray-500 font-mono text-sm text-center">
            <span className="code-comment">// Blending technology, logic, creativity, and philosophy</span>
          </p>
          
          <p className="text-gray-600 font-mono text-sm">
            © 2024 Kiopdev. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

// Main App
function App() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      smoothWheel: true
    });
    
    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    
    requestAnimationFrame(raf);
    
    lenis.on('scroll', ScrollTrigger.update);
    
    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });
    
    gsap.ticker.lagSmoothing(0);
    
    return () => {
      lenis.destroy();
    };
  }, []);
  
  return (
    <div className="relative bg-[#0a0a0f] min-h-screen">
      <MatrixRain />
      <div className="fixed inset-0 pointer-events-none z-0 grid-pattern opacity-50" />
      <Navigation />
      
      <main className="relative z-10">
        <HeroSection />
        <AboutSection />
        <InterestsSection />
        <PhilosophySection />
        <LifestyleSection />
        <WritingSection />
        <SkillsSection />
        <ContactSection />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;
